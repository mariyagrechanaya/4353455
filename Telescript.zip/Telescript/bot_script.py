# bot_script.py (кроссплатформенный)
import os
import re
import sqlite3
import threading
import time
import random
import asyncio
import platform
import psutil
import logging
import sys
import argparse
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.types import MessageEntityMentionName

# Логирование
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DB_PATH = 'accounts.db'
FOLDERS_DIR = 'folders'
STOP_EVENT = threading.Event()

def limit_resources():
    try:
        proc = psutil.Process(os.getpid())
        total_cores = psutil.cpu_count(logical=False) or psutil.cpu_count()
        allowed = list(range(max(1, total_cores // 2)))
        proc.cpu_affinity(allowed)
    except (AttributeError, NotImplementedError):
        logger.warning("⚠️ cpu_affinity не поддерживается на этой платформе")
    if platform.system() != 'Windows':
        try:
            import resource
            gb = 2 * 1024 ** 3
            resource.setrlimit(resource.RLIMIT_AS, (gb, gb))
        except Exception as e:
            logger.warning(f"⚠️ Не удалось установить ограничение памяти: {e}")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT,
            api_id INTEGER NOT NULL,
            api_hash TEXT NOT NULL,
            string_session TEXT,
            folder_number INTEGER NOT NULL DEFAULT 0
        );
    ''')
    conn.commit()
    conn.close()

def get_accounts():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT id, phone, api_id, api_hash, string_session, folder_number FROM accounts')
    rows = cur.fetchall()
    conn.close()
    return rows

def add_account(phone, api_id, api_hash, string_session, folder_number):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO accounts (phone, api_id, api_hash, string_session, folder_number) VALUES (?, ?, ?, ?, ?)',
        (phone, api_id, api_hash, string_session, folder_number)
    )
    conn.commit()
    conn.close()
    logger.info(f"Добавлен аккаунт: {phone or '[StringSession]'} (папка {folder_number})")

def update_account(acc_id, phone=None, api_id=None, api_hash=None, string_session=None, folder_number=None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT phone, api_id, api_hash, string_session, folder_number FROM accounts WHERE id=?', (acc_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        raise ValueError(f"Аккаунт ID {acc_id} не найден")
    cur_phone, cur_api_id, cur_api_hash, cur_ss, cur_folder = row
    new_phone = phone if phone is not None else cur_phone
    new_api_id = api_id if api_id is not None else cur_api_id
    new_api_hash = api_hash if api_hash is not None else cur_api_hash
    new_ss = string_session if string_session is not None else cur_ss
    new_folder = folder_number if folder_number is not None else cur_folder
    cur.execute(
        '''UPDATE accounts
           SET phone=?, api_id=?, api_hash=?, string_session=?, folder_number=?
           WHERE id=?''',
        (new_phone, new_api_id, new_api_hash, new_ss, new_folder, acc_id)
    )
    conn.commit()
    conn.close()
    logger.info(f"Обновлён аккаунт ID {acc_id}: папка {new_folder}")

def delete_account(acc_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT phone FROM accounts WHERE id=?', (acc_id,))
    row = cur.fetchone()
    cur.execute('DELETE FROM accounts WHERE id=?', (acc_id,))
    conn.commit()
    conn.close()
    logger.info(f"Удалён аккаунт ID {acc_id}: {row[0] if row else ''}")

async def save_group_if_writable(client, entity_name, joined_path):
    try:
        entity = await client.get_entity(entity_name)
        if getattr(entity, 'broadcast', False):
            return
        msg = await client.send_message(entity, '.')
        await client.delete_messages(entity, msg)
        os.makedirs(os.path.dirname(joined_path), exist_ok=True)
        existing = []
        if os.path.exists(joined_path):
            with open(joined_path, 'r', encoding='utf-8') as f:
                existing = [l.strip() for l in f if l.strip()]
        if entity_name not in existing:
            with open(joined_path, 'a', encoding='utf-8') as f:
                f.write(entity_name + '\n')
    except:
        pass

def read_time_hold(folder_path):
    path = os.path.join(folder_path, 'time_hold.txt')
    if not os.path.exists(path):
        return 20.0, 40.0
    try:
        text = open(path, encoding='utf-8').read().strip()
        parts = [p.strip() for p in text.split(',')]
        if len(parts) != 2:
            raise ValueError
        mn = float(parts[0]); mx = float(parts[1])
        if mn < 0 or mx < 0 or mn > mx:
            raise ValueError
        return mn, mx
    except Exception:
        logger.warning(f"Неверный формат time_hold.txt в {folder_path}, используется дефолт 20-40s")
        return 20.0, 40.0

async def import_addlist(client, hash_str):
    joined = []
    try:
        res = await client(ImportChatInviteRequest(hash_str))
        chats = getattr(res, 'chats', None)
        if chats:
            for chat in chats:
                name = chat.username or str(chat.id)
                joined.append(name)
    except Exception as e:
        logger.warning(f"Не удалось импортировать addlist {hash_str}: {e}")
    return joined

def extract_addlist_hash(text):
    m = re.search(r'(?:https?://)?t\.me/addlist/([\w\d_-]+)', text)
    if m:
        return m.group(1)
    return None

async def worker(account):
    acc_id, phone, api_id, api_hash, string_session, folder_number = account
    folder = os.path.join(FOLDERS_DIR, str(folder_number))
    settings_file = os.path.join(folder, 'ADD_NEW_CHANNELS.txt')
    static_file = os.path.join(folder, 'channel.txt')  # статические группы
    joined_file = os.path.join(folder, 'joined_groups.txt')
    tmpl_mention = os.path.join(folder, 'template.txt')
    tmpl_private = os.path.join(folder, 'template_private.txt')
    tmpl_group = os.path.join(folder, 'template_group.txt')

    if not os.path.exists(settings_file) or not os.path.exists(static_file):
        logger.warning(f"Аккаунт ID {acc_id}: пропускаем — нет файлов настроек в папке {folder_number}")
        return

    ADD_NEW = open(settings_file, encoding='utf-8').read().strip().lower() == 'true'

    # Читаем статический список
    static_list = []
    with open(static_file, encoding='utf-8') as f:
        for line in f:
            item = line.strip()
            if item:
                static_list.append(item)

    # Подготовка joined_file
    os.makedirs(os.path.dirname(joined_file), exist_ok=True)
    existing = []
    if os.path.exists(joined_file):
        with open(joined_file, 'r', encoding='utf-8') as f:
            existing = [l.strip() for l in f if l.strip()]

    # Подключение по StringSession
    if not string_session or not string_session.strip():
        logger.warning(f"Аккаунт ID {acc_id}: пропускаем — нет StringSession")
        return
    try:
        client = TelegramClient(StringSession(string_session), api_id, api_hash)
        await client.connect()
        if not await client.is_user_authorized():
            logger.warning(f"Аккаунт ID {acc_id}: StringSession недействителен, пропускаем")
            await client.disconnect()
            return
    except Exception as e:
        logger.warning(f"Аккаунт ID {acc_id}: ошибка подключения по StringSession: {e}, пропускаем")
        return

    try:
        me = await client.get_me()
    except Exception as e:
        logger.warning(f"Аккаунт ID {acc_id}: не удалось получить себя: {e}, пропускаем")
        await client.disconnect()
        return

    username = me.username or str(me.id)
    user_id = me.id
    logger.info(f"Аккаунт ID {acc_id} ({username}) запущен")

    # Обработка статических: импорт addlist и замена ссылки на список чатов
    updated_static = []  # новая версия списка
    changed = False
    for item in static_list:
        h = extract_addlist_hash(item)
        if h:
            # импортируем группы
            joined = await import_addlist(client, h)
            if joined:
                logger.info(f"Импорт из addlist {h}: найдено {len(joined)} чатов")
                # Добавляем в static_file: заменяем ссылку на имена/ID чатов
                for grp in joined:
                    if grp not in updated_static:
                        updated_static.append(grp)
                changed = True
                # Также добавляем в joined_file, если нужно
                for grp in joined:
                    if grp not in existing:
                        with open(joined_file, 'a', encoding='utf-8') as jf:
                            jf.write(grp + '\n')
                        existing.append(grp)
            else:
                logger.warning(f"addlist {h} вернуло пустой список")
            # не добавляем самую ссылку в updated_static
        else:
            # обычный пункт
            updated_static.append(item)
    # Если были ссылки и они заменены, перезапишем static_file
    if changed:
        try:
            with open(static_file, 'w', encoding='utf-8') as f:
                for itm in updated_static:
                    f.write(itm + '\n')
            logger.info(f"channel.txt в папке {folder_number} обновлён: ссылки addlist заменены на конкретные группы")
        except Exception as e:
            logger.warning(f"Не удалось обновить {static_file}: {e}")

    # Если static_file был пуст или не содержал ссылок, просто добавляем первоначально все новые в joined_file
    if not changed:
        # при старте добавляем статические в joined_file, если их там нет
        for item in static_list:
            if item not in existing:
                with open(joined_file, 'a', encoding='utf-8') as jf:
                    jf.write(item + '\n')
                existing.append(item)

    # Читаем тексты ответов
    text_mention = open(tmpl_mention, encoding='utf-8').read().strip() if os.path.exists(tmpl_mention) else ''
    text_private = open(tmpl_private, encoding='utf-8').read().strip() if os.path.exists(tmpl_private) else ''
    text_group = open(tmpl_group, encoding='utf-8').read().strip() if os.path.exists(tmpl_group) else 'привет группе'

    mn_delay, mx_delay = read_time_hold(folder)

    # Первичное присоединение статических (после обновления файла)
    # Читаем обновлённый static_list
    static_list2 = updated_static if changed else static_list
    for item in static_list2:
        if STOP_EVENT.is_set():
            break
        try:
            await client(JoinChannelRequest(item))
            if ADD_NEW:
                await save_group_if_writable(client, item, joined_file)
        except:
            pass

    # Периодическая рассылка
    async def periodic_hello():
        cooldowns = {}
        while not STOP_EVENT.is_set():
            if psutil.cpu_percent(interval=0.5) > 90:
                await asyncio.sleep(1)
                continue
            path_to_use = joined_file if ADD_NEW else static_file
            if os.path.exists(path_to_use):
                now_ts = time.time()
                with open(path_to_use, encoding='utf-8') as f:
                    items = [l.strip() for l in f if l.strip()]
                for item in items:
                    if STOP_EVENT.is_set():
                        break
                    # попытка присоединения
                    try:
                        await client(JoinChannelRequest(item))
                    except:
                        pass
                    if cooldowns.get(item, 0) > now_ts:
                        continue
                    try:
                        await client.send_message(item, text_group)
                    except Exception as e:
                        s = str(e)
                        if 'A wait of' in s:
                            m0 = re.search(r'(\d+)', s)
                            if m0:
                                w = int(m0.group(1))
                                cooldowns[item] = now_ts + w
                    await asyncio.sleep(1)
            await asyncio.sleep(random.uniform(mn_delay, mx_delay))

    @client.on(events.NewMessage(incoming=True))
    async def on_message(event):
        if STOP_EVENT.is_set():
            return
        if event.is_private:
            try:
                await event.reply(text_private)
            except:
                pass
            return
        chat = await event.get_chat()
        cid = (chat.username or str(chat.id)).lstrip('@')
        path_to_use = joined_file if ADD_NEW else static_file
        allowed = []
        if os.path.exists(path_to_use):
            with open(path_to_use, 'r', encoding='utf-8') as f:
                allowed = [l.strip().lstrip('@') for l in f if l.strip()]
        if cid not in allowed:
            return
        text = event.raw_text or ''
        entities = event.message.entities or []
        mentioned = any(x in text.lower() for x in [f'@{username.lower()}', str(user_id)])
        for ent in entities:
            if isinstance(ent, MessageEntityMentionName) and ent.user_id == user_id:
                mentioned = True
                break
        if not mentioned:
            return
        # Обработка упоминаний: попытка join/group import аналогично выше
        targets = [w for w in re.findall(r'@[\w\d_]+', text) if w.lower() != f'@{username.lower()}']
        for row in (event.message.buttons or []):
            for btn in row:
                url = getattr(btn, 'url', '')
                h = extract_addlist_hash(url)
                if h:
                    targets.append(url)
                else:
                    m0 = re.search(r't\.me/([\w\d_]+)', url)
                    if m0:
                        targets.append('@' + m0.group(1))
        if targets:
            for tgt in set(targets):
                h = extract_addlist_hash(tgt)
                if h:
                    joined = await import_addlist(client, h)
                    for grp in joined:
                        if grp not in existing:
                            with open(joined_file, 'a', encoding='utf-8') as jf:
                                jf.write(grp + '\n')
                            existing.append(grp)
                else:
                    nm = tgt.lstrip('@')
                    try:
                        await client(JoinChannelRequest(nm))
                        if ADD_NEW:
                            await save_group_if_writable(client, nm, joined_file)
                    except:
                        pass
            return
        try:
            await event.reply(text_mention)
        except:
            pass

    # Запуск
    task = asyncio.create_task(periodic_hello())
    try:
        while not STOP_EVENT.is_set():
            try:
                await client.run_until_disconnected()
            except:
                await asyncio.sleep(5)
    finally:
        task.cancel()
        try:
            await client.disconnect()
        except:
            pass
        logger.info(f"Аккаунт ID {acc_id} ({username}) остановлен")

async def bot_main():
    limit_resources()
    init_db()
    accounts = get_accounts()
    tasks = [worker(acc) for acc in accounts]
    if tasks:
        await asyncio.gather(*tasks)

def start_bot():
    STOP_EVENT.clear()
    threading.Thread(target=lambda: asyncio.run(bot_main()), daemon=True).start()
    logger.info("Bot started...")

def stop_bot():
    STOP_EVENT.set()
    logger.info("Bot stopping...")

if __name__ == '__main__':
    start_bot()
    while True:
        try:
            time.sleep(1)
        except KeyboardInterrupt:
            stop_bot()
            break
