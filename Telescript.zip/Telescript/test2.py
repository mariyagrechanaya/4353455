import asyncio
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    FloodWaitError
)

# Константы:
API_ID = 25583498              # Замените на ваш API_ID
API_HASH = "583f6563db432820d804750080aeb97c"   # Замените на ваш API_HASH
PHONE = "+17622734915"       # Замените на номер телефона в международном формате
STRING_SESSION = '1AZWarzsBu16JrD58CdPNHfU3VYxC8Fw-nnaF7puf921MT9RSjwajykgYV4qr_dBFI9mxuVwcEaRgPUwlPIi0cufeXbGdDoDR_iwlVXQ5BYITWYTpIfT7FLYiMS3K04nCMcNT60mU6ASCETA_KB-Q84g1-SJG2LVTvGBVgtUSIz5zlpvL_-VRNN0Zg78CxDGLlr2kuOZ_hooeX2zDutCD84aeeUPWaY3FlVBz587DWBL1MBAz8cnBXk3Or9jFqqVZ2RU9vWG_qpHjfeYSfbrxgR6t4DsyXsjaE4RmkBbtZQT53GQNB-_hZ8pUfIz2Z0YOFbmc6UfP0mRJWPdUA-cQkHPEU6CEJDM='

async def login_and_print_session():
    # Если задана константа StringSession, пытаемся подключиться по ней
    if STRING_SESSION:
        client = TelegramClient(StringSession(STRING_SESSION), API_ID, API_HASH)
        await client.connect()
        try:
            if not await client.is_user_authorized():
                print("StringSession недействителен или неавторизован.")
                await client.disconnect()
            else:
                me = await client.get_me()
                print(f"Успешно подключились по StringSession как {me.first_name} (ID: {me.id})")
                # При желании, можно сохранить или вывести session, но мы используем константу
        except Exception as e:
            print(f"Ошибка при подключении по StringSession: {e}")
            try:
                await client.disconnect()
            except:
                pass
        return

    # Если StringSession не задан, выполняем вход по телефону
    client = TelegramClient(StringSession(), API_ID, API_HASH)
    await client.connect()
    try:
        if not await client.is_user_authorized():
            try:
                await client.send_code_request(PHONE)
                print(f"Код отправлен на {PHONE}")
            except FloodWaitError as e:
                print(f"Слишком частые запросы: нужно ждать {e.seconds} секунд")
                return
            except Exception as e:
                print(f"Ошибка при отправке кода: {e}")
                return

            code = input("Введите код из Telegram: ").strip()
            try:
                await client.sign_in(phone=PHONE, code=code)
            except SessionPasswordNeededError:
                pwd = input("Введите 2FA-пароль: ").strip()
                try:
                    await client.sign_in(password=pwd)
                except Exception as e:
                    print(f"Ошибка 2FA: {e}")
                    return
            except PhoneCodeInvalidError:
                print("Неверный код.")
                return
            except PhoneCodeExpiredError:
                print("Код истёк.")
                return
            except Exception as e:
                print(f"Ошибка при входе с кодом: {e}")
                return

        # Уже авторизованы или успешно вошли
        me = await client.get_me()
        session_str = client.session.save()
        print(f"Успешно вошли как {me.first_name} (ID: {me.id})")
        print(f"StringSession: {session_str}")
    finally:
        await client.disconnect()

def main():
    asyncio.run(login_and_print_session())

if __name__ == "__main__":
    main()
