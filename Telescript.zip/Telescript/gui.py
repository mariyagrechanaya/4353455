import datetime
import logging
import os
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, simpledialog, filedialog

from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneCodeExpiredError, FloodWaitError
from telethon.sessions import StringSession
from telethon.sync import TelegramClient as SyncTelegramClient

from bot_script import (
    init_db, add_account,
    update_account, delete_account,
    get_accounts,
    start_bot, stop_bot
)

DB_PATH = 'accounts.db'
FOLDERS_DIR = 'folders'


class GuiLoggerHandler(logging.Handler):
    """Handler, пишущий логи в ScrolledText."""

    def __init__(self, text_widget):
        super().__init__()
        self.text_widget = text_widget
        self.text_widget.configure(state='disabled')

    def emit(self, record):
        msg = self.format(record)
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        line = f"[{timestamp}] {msg}\n"
        self.text_widget.configure(state='normal')
        self.text_widget.insert(tk.END, line)
        self.text_widget.yview(tk.END)
        self.text_widget.configure(state='disabled')


class BotGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Telegram Bot Manager")
        self.geometry("1200x700")
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)

        os.makedirs(FOLDERS_DIR, exist_ok=True)
        init_db()
        self.selected_account_id = None

        self._build_ui()
        self._configure_logging()

    def _configure_logging(self):
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)
        fmt = logging.Formatter('%(levelname)s: %(message)s')
        handler = GuiLoggerHandler(self.txt_logs)
        handler.setFormatter(fmt)
        self.logger.addHandler(handler)

    def _build_ui(self):
        # Toolbar
        toolbar = ttk.Frame(self)
        toolbar.grid(row=0, column=0, sticky='ew')
        toolbar.columnconfigure(0, weight=1)
        btn_help = ttk.Button(toolbar, text="Справка", command=self._show_help)
        btn_help.pack(anchor='e', padx=5, pady=5)

        # Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=1, column=0, sticky='nsew')
        self._build_accounts_tab(self.notebook)
        self._build_folders_tab(self.notebook)
        self._build_logs_tab(self.notebook)

        # Кнопка "?"
        question_btn = ttk.Button(self, text="?", width=3, command=self._show_help)
        question_btn.grid(row=2, column=0, sticky='sw', padx=10, pady=10)

    def _show_help(self):
        help_text = (
            "Инструкция по работе:\n\n"
            "Вкладка «Аккаунты» — управление аккаунтами Telegram.\n"
            "  • Добавление: вход по телефону (SMS + 2FA) или по StringSession.\n"
            "  • При добавлении по телефону: отправка кода, ввод пользователем, 2FA при необходимости, "
            "сохранение сессии.\n"
            "  • Редактирование: изменение полей, проверка новой StringSession.\n\n"
            "Вкладка «Папки» — настройка шаблонов:\n"
            "  • ADD_NEW_CHANNELS.txt\n"
            "  • channel.txt, joined_channels.txt, template.txt, template_private.txt, template_channel.txt\n"
            "  • num_of_channels.txt (максимум каналов в joined_channels)\n\n"
            "Вкладка «Логи» — события бота в реальном времени.\n\n"
            "Кнопки «Запустить бот»/«Остановить бот» управляют фоном."
        )
        messagebox.showinfo("Справка", help_text)

    # ─── Accounts Tab ───
    def _build_accounts_tab(self, parent):
        frame = ttk.Frame(parent)
        parent.add(frame, text="Аккаунты")
        frame.rowconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)

        cols = ("id", "phone", "api_id", "api_hash", "string_session", "folder")
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")
        for c in cols:
            self.tree.heading(c, text=c.capitalize())
            self.tree.column(c, width=120, anchor='center')
        self.tree.grid(row=1, column=0, sticky='nsew', padx=5, pady=5)
        self.tree.bind("<<TreeviewSelect>>", self._on_account_select)

        form = ttk.Frame(frame)
        form.grid(row=2, column=0, sticky='ew', padx=5, pady=5)
        for i in range(4):
            form.columnconfigure(i, weight=1)

        self.var_type = tk.StringVar(value='phone')
        ttk.Radiobutton(form, text="Вход по телефону", variable=self.var_type, value='phone',
                        command=self._update_fields).grid(row=0, column=0, sticky='w')
        ttk.Radiobutton(form, text="Вход по StringSession", variable=self.var_type, value='ss',
                        command=self._update_fields).grid(row=0, column=1, sticky='w')

        ttk.Label(form, text="Номер телефона:").grid(row=1, column=0, sticky='e')
        self.ent_phone = ttk.Entry(form)
        self.ent_phone.grid(row=1, column=1, sticky='we', padx=5)
        ttk.Label(form, text="API_ID:").grid(row=2, column=0, sticky='e')
        self.ent_api_id = ttk.Entry(form)
        self.ent_api_id.grid(row=2, column=1, sticky='we', padx=5)
        ttk.Label(form, text="API_HASH:").grid(row=2, column=2, sticky='e')
        self.ent_api_hash = ttk.Entry(form)
        self.ent_api_hash.grid(row=2, column=3, sticky='we', padx=5)
        ttk.Label(form, text="StringSession:").grid(row=3, column=0, sticky='e')
        self.ent_ss = ttk.Entry(form)
        self.ent_ss.grid(row=3, column=1, columnspan=3, sticky='we', padx=5)
        ttk.Label(form, text="Номер папки:").grid(row=4, column=0, sticky='e')
        self.cmb_folder = ttk.Combobox(form, values=self._list_folders(), state='readonly')
        self.cmb_folder.grid(row=4, column=1, sticky='we', padx=5)

        btns = ttk.Frame(frame)
        btns.grid(row=3, column=0, sticky='ew', pady=10)
        for i in range(8):
            btns.columnconfigure(i, weight=0)
        btns.columnconfigure(6, weight=1)

        self.btn_add = ttk.Button(btns, text="Добавить аккаунт", command=self._add_account)
        self.btn_add.grid(row=0, column=0, padx=5)
        self.btn_save = ttk.Button(btns, text="Сохранить изменения", command=self._save_account)
        self.btn_save.grid(row=0, column=1, padx=5)
        self.btn_delete = ttk.Button(btns, text="Удалить аккаунт", command=self._delete_account)
        self.btn_delete.grid(row=0, column=2, padx=5)
        self.btn_cancel = ttk.Button(btns, text="Отменить редактирование", command=self._cancel_edit)
        self.btn_cancel.grid(row=0, column=3, padx=5)
        ttk.Button(btns, text="Запустить бота", command=self._start_bot_and_log).grid(row=0, column=4, padx=20)
        ttk.Button(btns, text="Остановить бота", command=self._stop_bot_and_log).grid(row=0, column=5, padx=5)
        ttk.Button(btns, text="Создать резервную копию БД", command=self._backup_db) \
            .grid(row=0, column=6, padx=5, sticky='e')
        ttk.Button(btns, text="Восстановить из резервной копии", command=self._restore_db) \
            .grid(row=0, column=7, padx=5, sticky='e')

        self._update_fields()
        self._load_accounts()
        self._cancel_edit()

    def _start_bot_and_log(self):
        logging.info("Запуск бота...")
        start_bot()

    def _stop_bot_and_log(self):
        stop_bot()
        logging.info("Бот остановлен.")

    def _list_folders(self):
        return sorted(d for d in os.listdir(FOLDERS_DIR)
                      if os.path.isdir(os.path.join(FOLDERS_DIR, d)))

    def _update_fields(self):
        if self.var_type.get() == 'phone':
            self.ent_phone.config(state='normal')
            self.ent_ss.config(state='disabled')
        else:
            self.ent_phone.config(state='disabled')
            self.ent_ss.config(state='normal')

    def _backup_db(self):
        if not os.path.exists(DB_PATH):
            messagebox.showwarning("Ошибка", "Файл БД не найден.")
            return
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        path = f"accounts_backup_{ts}.db"
        try:
            shutil.copyfile(DB_PATH, path)
            messagebox.showinfo("Успех", f"Резервная копия сохранена как:\n{path}")
            logging.info(f"Создана резервная копия: {path}")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось создать бэкап:\n{e}")
            logging.error(f"Ошибка бэкапа: {e}")

    def _restore_db(self):
        fname = filedialog.askopenfilename(
            title="Выберите файл резервной копии",
            filetypes=[("SQLite БД", "*.db"), ("Все файлы", "*.*")]
        )
        if not fname:
            return
        try:
            shutil.copyfile(fname, DB_PATH)
            messagebox.showinfo("Успех", "БД восстановлена.")
            logging.info(f"БД восстановлена из: {fname}")
            self._load_accounts()
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось восстановить БД:\n{e}")
            logging.error(f"Ошибка восстановления: {e}")

    def _load_accounts(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        for rec in get_accounts():
            self.tree.insert("", "end", values=rec)
        self.cmb_folder['values'] = self._list_folders()

    def _on_account_select(self, _):
        sel = self.tree.selection()
        if not sel:
            return
        values = self.tree.item(sel[0], 'values')
        acc_id, phone, aid, ahash, ss, folder = values
        self.selected_account_id = int(acc_id)
        if phone:
            self.var_type.set('phone')
            self.ent_phone.config(state='normal')
            self.ent_phone.delete(0, tk.END)
            self.ent_phone.insert(0, phone)
        else:
            self.var_type.set('ss')
            self.ent_phone.delete(0, tk.END)
            self.ent_phone.config(state='disabled')
        self.ent_api_id.delete(0, tk.END)
        self.ent_api_id.insert(0, aid)
        self.ent_api_hash.delete(0, tk.END)
        self.ent_api_hash.insert(0, ahash)
        self.ent_ss.delete(0, tk.END)
        if ss:
            self.ent_ss.insert(0, ss)
        self.cmb_folder.set(str(folder))
        self._update_fields()
        self.btn_add.state(['disabled'])
        self.btn_save.state(['!disabled'])
        self.btn_delete.state(['!disabled'])
        self.btn_cancel.state(['!disabled'])

    def _add_account(self):
        mode = self.var_type.get()
        try:
            api_id = int(self.ent_api_id.get().strip())
        except ValueError:
            messagebox.showerror("Ошибка", "API_ID должен быть числом.")
            return
        api_hash = self.ent_api_hash.get().strip()
        if not api_hash:
            messagebox.showerror("Ошибка", "API_HASH обязателен.")
            return
        folder_str = self.cmb_folder.get().strip()
        try:
            folder = int(folder_str)
        except ValueError:
            messagebox.showerror("Ошибка", "Номер папки должен быть числом.")
            return
        if folder_str not in [str(d) for d in self._list_folders()]:
            messagebox.showerror("Ошибка", "Выберите существующий номер папки.")
            return

        if mode == 'phone':
            phone = self.ent_phone.get().strip()
            if not phone:
                messagebox.showerror("Ошибка", "Номер телефона обязателен.")
                return
            try:
                client = SyncTelegramClient(StringSession(), api_id, api_hash)
                client.connect()
            except Exception as e:
                messagebox.showerror("Ошибка подключения", f"Не получилось создать клиент: {e}")
                return
            try:
                logging.info(f"Отправляем код на {phone}...")
                client.send_code_request(phone)
            except FloodWaitError as fw:
                messagebox.showerror("Ошибка", f"Слишком частые запросы: {fw}")
                client.disconnect()
                return
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось отправить код: {e}")
                client.disconnect()
                return
            code = simpledialog.askstring("Код подтверждения", f"Введите код, отправленный на {phone}:")
            if code is None:
                messagebox.showinfo("Отменено", "Добавление аккаунта отменено.")
                client.disconnect()
                return
            try:
                client.sign_in(phone=phone, code=code)
            except SessionPasswordNeededError:
                pwd = simpledialog.askstring("2FA пароль", "Введите 2FA-пароль:", show='*')
                if pwd is None:
                    messagebox.showinfo("Отменено", "Добавление аккаунта отменено.")
                    client.disconnect()
                    return
                try:
                    client.sign_in(password=pwd)
                except Exception as e:
                    messagebox.showerror("Ошибка 2FA", f"Не удалось войти с 2FA-паролем: {e}")
                    client.disconnect()
                    return
            except PhoneCodeInvalidError:
                messagebox.showerror("Ошибка", "Неверный код. Попробуйте добавить аккаунт заново.")
                client.disconnect()
                return
            except PhoneCodeExpiredError:
                messagebox.showerror("Ошибка", "Код истёк. Попробуйте добавить аккаунт снова.")
                client.disconnect()
                return
            except FloodWaitError as fw:
                messagebox.showerror("Ошибка", f"Слишком частые попытки: {fw}")
                client.disconnect()
                return
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось войти с кодом: {e}")
                client.disconnect()
                return
            try:
                new_ss = client.session.save()
                client.disconnect()
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось сохранить сессию: {e}")
                try:
                    client.disconnect()
                except:
                    pass
                return
            try:
                add_account(phone, api_id, api_hash, new_ss, folder)
                messagebox.showinfo("Успех", "Аккаунт добавлен, StringSession сохранён.")
                logging.info(f"Добавлен аккаунт {phone}, сессия сохранена.")
            except Exception as e:
                messagebox.showerror("Ошибка БД", f"Не удалось добавить запись: {e}")
                logging.error(f"Ошибка при добавлении аккаунта: {e}")
                return
        else:
            ss = self.ent_ss.get().strip()
            if not ss:
                messagebox.showerror("Ошибка", "StringSession обязателен.")
                return
            try:
                client = SyncTelegramClient(StringSession(ss), api_id, api_hash)
                client.connect()
                client.get_me()
                client.disconnect()
            except Exception as e:
                messagebox.showerror("Ошибка", f"Недействительная StringSession или неверные api_id/api_hash: {e}")
                try:
                    client.disconnect()
                except:
                    pass
                return
            try:
                add_account(None, api_id, api_hash, ss, folder)
                messagebox.showinfo("Успех", "Аккаунт по StringSession добавлен.")
                logging.info("Добавлен аккаунт по StringSession.")
            except Exception as e:
                messagebox.showerror("Ошибка БД", f"Не удалось добавить запись: {e}")
                logging.error(f"Ошибка при добавлении аккаунта: {e}")
                return

        self._load_accounts()
        self._cancel_edit()

    def _save_account(self):
        if self.selected_account_id is None:
            return
        mode = self.var_type.get()
        try:
            api_id = int(self.ent_api_id.get().strip())
        except ValueError:
            messagebox.showerror("Ошибка", "API_ID должен быть числом.")
            return
        api_hash = self.ent_api_hash.get().strip()
        if not api_hash:
            messagebox.showerror("Ошибка", "API_HASH обязателен.")
            return
        folder_str = self.cmb_folder.get().strip()
        try:
            folder = int(folder_str)
        except ValueError:
            messagebox.showerror("Ошибка", "Номер папки должен быть числом.")
            return
        if folder_str not in [str(d) for d in self._list_folders()]:
            messagebox.showerror("Ошибка", "Выберите существующий номер папки.")
            return

        if mode == 'phone':
            phone = self.ent_phone.get().strip()
            if not phone:
                messagebox.showerror("Ошибка", "Номер телефона обязателен.")
                return
            try:
                update_account(self.selected_account_id,
                               phone=phone,
                               api_id=api_id,
                               api_hash=api_hash,
                               string_session='',
                               folder_number=folder)
                messagebox.showinfo("Успех", "Данные аккаунта обновлены. StringSession сброшен.")
                logging.info(f"Обновлён аккаунт ID {self.selected_account_id}, сброшена сессия.")
            except Exception as e:
                messagebox.showerror("Ошибка БД", f"Не удалось сохранить изменения: {e}")
                logging.error(f"Ошибка при обновлении аккаунта: {e}")
                return
        else:
            ss = self.ent_ss.get().strip()
            if not ss:
                messagebox.showerror("Ошибка", "StringSession обязателен.")
                return
            try:
                client = SyncTelegramClient(StringSession(ss), api_id, api_hash)
                client.connect()
                client.get_me()
                client.disconnect()
            except Exception as e:
                messagebox.showerror("Ошибка", f"Недействительная StringSession или неверные api_id/api_hash: {e}")
                try:
                    client.disconnect()
                except:
                    pass
                return
            try:
                update_account(self.selected_account_id,
                               phone=None,
                               api_id=api_id,
                               api_hash=api_hash,
                               string_session=ss,
                               folder_number=folder)
                messagebox.showinfo("Успех", "Аккаунт по StringSession обновлён.")
                logging.info(f"Обновлён аккаунт ID {self.selected_account_id} по StringSession.")
            except Exception as e:
                messagebox.showerror("Ошибка БД", f"Не удалось сохранить изменения: {e}")
                logging.error(f"Ошибка при обновлении аккаунта: {e}")
                return

        self._load_accounts()
        self._cancel_edit()

    def _delete_account(self):
        sel = self.tree.selection()
        if not sel:
            return
        values = self.tree.item(sel[0], 'values')
        acc_id = int(values[0])
        if messagebox.askyesno("Подтверждение", "Удалить аккаунт?"):
            try:
                delete_account(acc_id)
                messagebox.showinfo("Удалено", "Аккаунт удалён.")
                logging.info(f"Удалён аккаунт ID {acc_id}")
            except Exception as e:
                messagebox.showerror("Ошибка БД", f"Не удалось удалить: {e}")
                logging.error(f"Ошибка при удалении аккаунта: {e}")
            self._load_accounts()
            self._cancel_edit()

    def _cancel_edit(self):
        self.tree.selection_remove(self.tree.selection())
        self.selected_account_id = None
        for w in (self.ent_phone, self.ent_api_id, self.ent_api_hash, self.ent_ss):
            w.delete(0, tk.END)
        self.cmb_folder.set('')
        self.var_type.set('phone')
        self._update_fields()
        self.btn_add.state(['!disabled'])
        self.btn_save.state(['disabled'])
        self.btn_delete.state(['disabled'])
        self.btn_cancel.state(['disabled'])

    # ─── Folders Tab ───
    def _build_folders_tab(self, parent):
        frame = ttk.Frame(parent)
        parent.add(frame, text="Папки")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)

        left = ttk.Frame(frame)
        left.grid(row=0, column=0, sticky='ns', padx=5, pady=5)
        ttk.Label(left, text="Список папок:").pack(anchor='nw')
        self.lst_folders = tk.Listbox(left, height=20)
        self.lst_folders.pack(fill='y', expand=False)
        for d in self._list_folders():
            self.lst_folders.insert(tk.END, d)
        self.lst_folders.bind('<<ListboxSelect>>', self._on_folder_select)
        ttk.Button(left, text="Создать новую папку", command=self._create_folder).pack(fill='x', pady=2)
        ttk.Button(left, text="Удалить выбранную папку", command=self._delete_folder).pack(fill='x', pady=2)

        right = ttk.Frame(frame)
        right.grid(row=0, column=1, sticky='nsew', padx=5, pady=5)
        for i in range(15):
            right.rowconfigure(i, weight=(1 if i % 2 == 1 else 0))
        right.columnconfigure(0, weight=1)

        self.var_add = tk.BooleanVar()
        ttk.Checkbutton(right, text="Авто-добавление новых каналов", variable=self.var_add) \
            .grid(row=0, column=0, sticky='w', pady=2)

        # Максимум каналов
        ttk.Label(right, text="Макс каналов в joined (≤1000):").grid(row=1, column=0, sticky='w')
        self.var_max_channels = tk.StringVar()
        self.ent_max_channels = ttk.Entry(right, textvariable=self.var_max_channels, width=10)
        self.ent_max_channels.grid(row=2, column=0, sticky='w', pady=2)

        def validate_int(newval):
            if newval == "":
                return True
            if newval.isdigit():
                try:
                    v = int(newval)
                    return 0 <= v <= 1000
                except:
                    return False
            return False

        vcmd = (self.register(validate_int), '%P')
        self.ent_max_channels.config(validate='key', validatecommand=vcmd)

        labels = (
            ("channel.txt (статические каналы)", 'txt_channel'),
            ("joined_channels.txt (авто-добавленные)", 'txt_joined'),
            ("template.txt (ответ на упоминание)", 'txt_tmpl'),
            ("template_private.txt (ответ в ЛС)", 'txt_priv'),
            ("template_channel.txt (рассылка)", 'txt_chan_tmpl'),
        )
        idx0 = 3
        for i, (label, attr) in enumerate(labels):
            row_label = idx0 + i * 2
            row_text = row_label + 1
            ttk.Label(right, text=label).grid(row=row_label, column=0, sticky='w')
            widget = scrolledtext.ScrolledText(right, height=4)
            widget.grid(row=row_text, column=0, sticky='nsew', pady=2)
            setattr(self, attr, widget)

        ttk.Button(right, text="Сохранить настройки папки", command=self._save_folder) \
            .grid(row=idx0 + len(labels) * 2, column=0, sticky='e', pady=10)

    def _create_folder(self):
        name = simpledialog.askstring("Новая папка", "Введите имя папки:")
        if not name:
            return
        path = os.path.join(FOLDERS_DIR, name)
        try:
            os.makedirs(path, exist_ok=True)
            for fn in (
                    'channel.txt', 'joined_channels.txt',
                    'template.txt', 'template_private.txt',
                    'template_channel.txt', 'ADD_NEW_CHANNELS.txt',
                    'num_of_channels.txt'
            ):
                open(os.path.join(path, fn), 'a', encoding='utf-8').close()
            self._refresh_folders_list()
            logging.info(f"Создана папка: {name}")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось создать папку: {e}")
            logging.error(f"Ошибка при создании папки: {e}")

    def _delete_folder(self):
        sel = self.lst_folders.curselection()
        if not sel:
            return
        folder = self.lst_folders.get(sel[0])
        if messagebox.askyesno("Подтверждение", f"Удалить папку «{folder}»?"):
            try:
                shutil.rmtree(os.path.join(FOLDERS_DIR, folder))
                self._refresh_folders_list()
                logging.info(f"Удалена папка: {folder}")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось удалить папку: {e}")
                logging.error(f"Ошибка при удалении папки: {e}")

    def _refresh_folders_list(self):
        self.lst_folders.delete(0, tk.END)
        for d in self._list_folders():
            self.lst_folders.insert(tk.END, d)
        self.cmb_folder['values'] = self._list_folders()

    def _on_folder_select(self, _):
        sel = self.lst_folders.curselection()
        if not sel:
            return
        folder = self.lst_folders.get(sel[0])
        base = os.path.join(FOLDERS_DIR, folder)

        add_file = os.path.join(base, 'ADD_NEW_CHANNELS.txt')
        val = False
        if os.path.exists(add_file):
            try:
                val = open(add_file, encoding='utf-8').read().strip().lower() == 'true'
            except:
                val = False
        self.var_add.set(val)

        # Чтение num_of_channels.txt
        max_file = os.path.join(base, 'num_of_channels.txt')
        max_val = ""
        if os.path.exists(max_file):
            try:
                txt = open(max_file, encoding='utf-8').read().strip()
                if txt.isdigit():
                    max_val = str(int(txt))
            except:
                max_val = ""
        self.var_max_channels.set(max_val)

        for fn, widget in (
                ('channel.txt', self.txt_channel),
                ('joined_channels.txt', self.txt_joined),
                ('template.txt', self.txt_tmpl),
                ('template_private.txt', self.txt_priv),
                ('template_channel.txt', self.txt_chan_tmpl),
        ):
            path = os.path.join(base, fn)
            widget.delete('1.0', tk.END)
            if os.path.exists(path):
                try:
                    widget.insert(tk.END, open(path, encoding='utf-8').read())
                except:
                    pass

    def _save_folder(self):
        sel = self.lst_folders.curselection()
        if not sel:
            return
        folder = self.lst_folders.get(sel[0])
        base = os.path.join(FOLDERS_DIR, folder)
        os.makedirs(base, exist_ok=True)

        try:
            with open(os.path.join(base, 'ADD_NEW_CHANNELS.txt'), 'w', encoding='utf-8') as f:
                f.write('True' if self.var_add.get() else 'False')
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить ADD_NEW_CHANNELS: {e}")
            return

        # Сохранение num_of_channels.txt
        max_val = self.var_max_channels.get().strip()
        try:
            if max_val == "":
                open(os.path.join(base, 'num_of_channels.txt'), 'w', encoding='utf-8').close()
            else:
                v = int(max_val)
                if v < 0 or v > 1000:
                    raise ValueError("Должно быть 0–1000")
                with open(os.path.join(base, 'num_of_channels.txt'), 'w', encoding='utf-8') as f:
                    f.write(str(v))
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить max каналов: {e}")
            return

        for fn, widget in (
                ('channel.txt', self.txt_channel),
                ('joined_channels.txt', self.txt_joined),
                ('template.txt', self.txt_tmpl),
                ('template_private.txt', self.txt_priv),
                ('template_channel.txt', self.txt_chan_tmpl),
        ):
            try:
                content = widget.get('1.0', tk.END).strip()
                with open(os.path.join(base, fn), 'w', encoding='utf-8') as f:
                    f.write(content)
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось сохранить {fn}: {e}")
                return

        messagebox.showinfo("Успех", f"Настройки папки «{folder}» сохранены.")
        logging.info(f"Сохранены настройки папки: {folder}")

    # ─── Logs Tab ───
    def _build_logs_tab(self, parent):
        frame = ttk.Frame(parent)
        parent.add(frame, text="Логи")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.txt_logs = scrolledtext.ScrolledText(frame, state='disabled', wrap='word')
        self.txt_logs.grid(row=0, column=0, sticky='nsew', padx=5, pady=5)


if __name__ == '__main__':
    app = BotGUI()
    app.mainloop()
