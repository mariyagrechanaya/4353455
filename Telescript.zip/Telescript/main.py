import asyncio
import os
import random
import re
import sqlite3
import time
from telethon import TelegramClient, events
from telethon.sessions import StringSession
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.types import MessageEntityMentionName

DB_PATH = 'accounts.db'

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT,
            api_id INTEGER NOT NULL,
            api_hash TEXT NOT NULL,
            string_session TEXT,
            folder_number INTEGER NOT NULL DEFAULT 0
        );
    ''')
    conn.commit()
    conn.close()

def add_account_string(api_id, api_hash, string_session, folder_number):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO accounts (phone, api_id, api_hash, string_session, folder_number) VALUES (NULL, ?, ?, ?, ?);',
        (api_id, api_hash, string_session, folder_number)
    )
    conn.commit()
    conn.close()

def get_accounts():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('SELECT phone, api_id, api_hash, string_session, folder_number FROM accounts;')
    rows = cur.fetchall()
    conn.close()
    return rows

async def save_channel_if_writable(client, entity_name, joined_path):
    try:
        entity = await client.get_entity(entity_name)
        if getattr(entity, 'broadcast', False):
            return
        msg = await client.send_message(entity, message='.')
        await client.delete_messages(entity, msg)

        if not os.path.exists(joined_path):
            with open(joined_path, 'w', encoding='utf-8') as f:
                f.write(f'{entity_name}\n')
        else:
            with open(joined_path, 'r+', encoding='utf-8') as f:
                lines = [line.strip() for line in f.readlines()]
                if entity_name not in lines:
                    f.write(f'{entity_name}\n')
        print(f'[✓] Сохранил канал {entity_name}')
    except Exception as e:
        print(f'[!] Не смог сохранить канал {entity_name}: {e}')

async def worker(account):
    phone, api_id, api_hash, string_session, folder_number = account
    folder = f'folders/{folder_number}/'
    channel_file = os.path.join(folder, 'channel.txt')
    joined_file = os.path.join(folder, 'joined_channels.txt')
    template_file = os.path.join(folder, 'template.txt')
    private_template_file = os.path.join(folder, 'template_private.txt')
    settings_file = os.path.join(folder, 'ADD_NEW_CHANNELS.txt')

    if not os.path.exists(settings_file):
        print(f'[!] Не найден {settings_file}')
        return
    with open(settings_file, encoding='utf-8') as f:
        ADD_NEW_CHANNELS = f.read().strip().lower() == 'true'

    client = TelegramClient(StringSession(string_session), api_id, api_hash)

    await client.start()
    me = await client.get_me()
    username = me.username or str(me.id)
    user_id = me.id

    if not os.path.exists(channel_file):
        print(f'[!] Нет файла channel.txt для {username}')
        return

    with open(channel_file, encoding='utf-8') as f:
        static_channels = [line.strip() for line in f if line.strip()]

    with open(template_file, encoding='utf-8') as f:
        template = f.read()

    with open(private_template_file, encoding='utf-8') as f:
        template_private = f.read()

    channels_path = joined_file if ADD_NEW_CHANNELS else channel_file

    try:
        for ch in static_channels:
            await client(JoinChannelRequest(channel=ch))
            if ADD_NEW_CHANNELS:
                await save_channel_if_writable(client, ch, joined_file)
            print(f'[{username}] Вступил в {ch}')
    except Exception as e:
        print(f'[{username}] Ошибка при вступлении: {e}')

    async def periodic_hello():
        channel_cooldowns = {}
        while True:
            now = time.time()
            with open(channels_path, encoding='utf-8') as f:
                channels = [line.strip() for line in f if line.strip()]
            for ch in channels:
                if channel_cooldowns.get(ch, 0) > now:
                    continue
                try:
                    await client.send_message(ch, 'привет')
                    print(f'[{username}] привет → {ch}')
                except Exception as e:
                    if 'A wait of' in str(e):
                        wait = int(re.search(r'(\d+)', str(e)).group(1))
                        channel_cooldowns[ch] = now + wait
                        print(f'[{username}] Flood в {ch} на {wait} сек.')
                    else:
                        print(f'[{username}] Ошибка в {ch}: {e}')
                await asyncio.sleep(1)
            await asyncio.sleep(random.randint(20, 40))

    @client.on(events.NewMessage(incoming=True))
    async def on_message(event):
        if event.is_private:
            try:
                await event.reply(template_private)
                print(f'[{username}] Ответ в ЛС')
            except:
                pass
            return

        entity = await event.get_chat()
        chat_id = entity.username or str(entity.id)

        with open(channels_path, encoding='utf-8') as f:
            allowed = [line.strip().lstrip('@') for line in f if line.strip()]
        if str(chat_id).lstrip('@') not in allowed:
            return

        text = event.raw_text or ''
        buttons = event.message.buttons or []
        entities = event.message.entities or []

        mentioned = any(x in text.lower() for x in [f'@{username.lower()}', str(user_id)])
        for ent in entities:
            if isinstance(ent, MessageEntityMentionName) and ent.user_id == user_id:
                mentioned = True

        if not mentioned:
            return

        targets = [w for w in text.split() if w.startswith('@') and w.lower() != f'@{username.lower()}']
        for row in buttons:
            for btn in row:
                url = getattr(btn, 'url', None)
                if url:
                    m = re.search(r't\.me/([\w\d_]+)', url)
                    if m:
                        targets.append('@' + m.group(1))

        if targets:
            for target in set(targets):
                try:
                    await client(JoinChannelRequest(channel=target))
                    if ADD_NEW_CHANNELS:
                        await save_channel_if_writable(client, target, joined_file)
                    print(f'[{username}] Подписался на {target}')
                except Exception as e:
                    print(f'[{username}] Ошибка подписки на {target}: {e}')

        try:
            await event.reply(template)
            print(f'[{username}] Ответил по шаблону')
        except:
            pass

    asyncio.create_task(periodic_hello())
    while True:
        try:
            await client.run_until_disconnected()
        except Exception as e:
            print(f"[{username}] Ошибка соединения: {e}, повтор через 10 сек...")
            await asyncio.sleep(10)


async def main():
    init_db()
    accounts = get_accounts()
    tasks = [worker(acc) for acc in accounts]
    await asyncio.gather(*tasks)

if __name__ == '__main__':
    asyncio.run(main())
