import asyncio
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneCodeExpiredError, FloodWaitError

async def login_and_get_session(api_id: int, api_hash: str, phone: str):
    """
    Логинимся по номеру телефона, api_id и api_hash, возвращаем строку StringSession.
    """
    # Создаем клиент с пустой сессией
    client = TelegramClient(StringSession(), api_id, api_hash)
    await client.connect()
    if not await client.is_user_authorized():
        try:
            # Отправляем код на указанный номер
            await client.send_code_request(phone)
        except FloodWaitError as e:
            print(f"Слишком частые попытки запроса кода, подождите: {e.seconds} секунд")
            await client.disconnect()
            return None
        except Exception as e:
            print(f"Ошибка при отправке кода: {e}")
            await client.disconnect()
            return None

        # Ввод кода пользователем
        code = input(f"Введите код, полученный на номер {phone}: ").strip()
        try:
            # Пробуем войти с кодом
            await client.sign_in(phone=phone, code=code)
        except SessionPasswordNeededError:
            # Если включена 2FA, запрашиваем пароль
            pwd = input("Введите 2FA-пароль: ").strip()
            try:
                await client.sign_in(password=pwd)
            except Exception as e:
                print(f"Ошибка при входе с 2FA-паролем: {e}")
                await client.disconnect()
                return None
        except PhoneCodeInvalidError:
            print("Неверный код. Попробуйте ещё раз.")
            await client.disconnect()
            return None
        except PhoneCodeExpiredError:
            print("Код истёк. Попробуйте запустить скрипт снова.")
            await client.disconnect()
            return None
        except Exception as e:
            print(f"Ошибка при входе с кодом: {e}")
            await client.disconnect()
            return None

    # Если уже авторизованы или успешно вошли
    try:
        session_str = client.session.save()
        me = await client.get_me()
        print(f"Успешно вошли как {me.first_name} ({me.id}).")
        print(f"StringSession: {session_str}")
    except Exception as e:
        print(f"Ошибка при сохранении сессии: {e}")
        session_str = None
    await client.disconnect()
    return session_str

def main():
    # Запрос параметров у пользователя
    try:
        api_id = int(input("Введите API_ID: ").strip())
    except ValueError:
        print("API_ID должен быть числом.")
        return
    api_hash = input("Введите API_HASH: ").strip()
    phone = input("Введите номер телефона в международном формате (например +71234567890): ").strip()
    # Запускаем асинхронную функцию
    session = asyncio.run(login_and_get_session(api_id=api_id, api_hash=api_hash, phone=phone))
    if session:
        # При желании, сохранить session в файл
        save_path = "string_session.txt"
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(session)
            print(f"StringSession сохранён в {save_path}")
        except Exception as e:
            print(f"Не удалось сохранить StringSession в файл: {e}")

if __name__ == "__main__":
    main()
