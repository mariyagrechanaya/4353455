# bot_tg.py
import asyncio
import logging
import os
import re
from functools import wraps
import sys
import argparse
import telebot
from telebot import types
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneCodeExpiredError, FloodWaitError
from telethon.sessions import StringSession
from telethon.sync import TelegramClient as SyncTelegramClient

from bot_script import init_db, add_account, update_account, delete_account, get_accounts, start_bot, stop_bot, \
    FOLDERS_DIR

parser = argparse.ArgumentParser(description="Telegram Bot")
parser.add_argument('--token', '-t', help="Telegram Bot API Token", default=None)
args = parser.parse_args()
# Если передан параметр --token, используем его, иначе остаётся значение по умолчанию
API_TOKEN = args.token if args.token else 'YOUR_DEFAULT_TELEGRAM_BOT_TOKEN'

DB_PATH = 'accounts.db'

bot = telebot.TeleBot(API_TOKEN)
logging.basicConfig(level=logging.INFO)

(
    S_MAIN,
    S_ADD_ACCOUNT_PHONE, S_ADD_ACCOUNT_API_ID, S_ADD_ACCOUNT_API_HASH,
    S_ADD_ACCOUNT_SESSION, S_ADD_ACCOUNT_FOLDER, S_ADD_ACCOUNT_CODE, S_ADD_ACCOUNT_2FA,
    S_EDIT_SELECT, S_EDIT_FIELD_SELECT, S_EDIT_VALUE,
    S_DELETE_SELECT,
    S_FOLDER_SELECT, S_FOLDER_NEW, S_FOLDER_FILE_SELECT, S_FOLDER_FILE_EDIT,
    S_FOLDER_TIMEHOLD_EDIT,
) = range(17)

USER_STATE = {}


def ensure_db(f):
    @wraps(f)
    def wrapped(m, *args, **kwargs):
        init_db()
        os.makedirs(FOLDERS_DIR, exist_ok=True)
        return f(m, *args, **kwargs)

    return wrapped


def reset_state(user_id):
    USER_STATE[user_id] = {'state': S_MAIN}


def get_state(user_id):
    return USER_STATE.get(user_id, {}).get('state', S_MAIN)


def set_state(user_id, state):
    if user_id not in USER_STATE:
        USER_STATE[user_id] = {}
    USER_STATE[user_id]['state'] = state


def make_cancel_keyboard():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    kb.add("Отмена")
    return kb


FIELD_LABELS = {
    'phone': 'Номер телефона',
    'api_id': 'API ID',
    'api_hash': 'API Hash',
    'string_session': 'StringSession',
    'folder_number': 'Номер папки'
}


def send_main_menu(chat_id, user_id):
    reset_state(user_id)
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row('➕ Добавить аккаунт', '✏️ Редактировать аккаунт')
    kb.row('🗑 Удалить аккаунт', '📂 Управление папками')
    kb.row('📝 Логи', '⚙️ Запустить/Остановить бота')
    bot.send_message(chat_id, "Главное меню:", reply_markup=kb)


def send_edit_menu(chat_id, user_id):
    accounts = get_accounts()
    if not accounts:
        bot.send_message(chat_id, "Нет аккаунтов для редактирования.")
        return send_main_menu(chat_id, user_id)
    kb = types.InlineKeyboardMarkup()
    for rec in accounts:
        acc_id, phone, api_id, api_hash, ss, folder = rec
        disp = phone if phone else '[StringSession]'
        kb.add(types.InlineKeyboardButton(f"ID {acc_id} – {disp}", callback_data=f"edit_sel:{acc_id}"))
    kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_edit_select"))
    set_state(user_id, S_EDIT_SELECT)
    bot.send_message(chat_id, "Выберите аккаунт для редактирования:", reply_markup=kb)


def send_field_menu(chat_id, user_id):
    acc_id = USER_STATE[user_id].get('edit_id')
    if acc_id is None:
        return send_edit_menu(chat_id, user_id)
    kb = types.InlineKeyboardMarkup()
    for field, label in FIELD_LABELS.items():
        kb.add(types.InlineKeyboardButton(label, callback_data=f"edit_field:{field}"))
    kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_edit_fields"))
    set_state(user_id, S_EDIT_FIELD_SELECT)
    bot.send_message(chat_id, f"Аккаунт ID {acc_id}. Что вы хотите изменить?", reply_markup=kb)


def send_delete_menu(chat_id, user_id):
    accounts = get_accounts()
    if not accounts:
        bot.send_message(chat_id, "Нет аккаунтов для удаления.")
        return send_main_menu(chat_id, user_id)
    kb = types.InlineKeyboardMarkup()
    for rec in accounts:
        acc_id, phone, api_id, api_hash, ss, folder = rec
        disp = phone if phone else '[StringSession]'
        kb.add(types.InlineKeyboardButton(f"ID {acc_id} – {disp}", callback_data=f"delete_sel:{acc_id}"))
    kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_delete"))
    set_state(user_id, S_DELETE_SELECT)
    bot.send_message(chat_id, "Выберите аккаунт для удаления:", reply_markup=kb)


def send_folder_menu(chat_id, user_id):
    folders = [d for d in os.listdir(FOLDERS_DIR) if os.path.isdir(os.path.join(FOLDERS_DIR, d))]
    kb = types.InlineKeyboardMarkup()
    for name in folders:
        kb.add(types.InlineKeyboardButton(name, callback_data=f"folder_sel:{name}"))
    kb.add(types.InlineKeyboardButton("➕ Создать новую папку", callback_data="folder_new"))
    kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_folder"))
    set_state(user_id, S_FOLDER_SELECT)
    bot.send_message(chat_id, "Папки:", reply_markup=kb)


def send_folder_files_menu(chat_id, user_id, folder):
    base = os.path.join(FOLDERS_DIR, folder)
    add_new_path = os.path.join(base, 'ADD_NEW_CHANNELS.txt')
    add_new_val = False
    if os.path.exists(add_new_path):
        v = open(add_new_path, encoding='utf-8').read().strip().lower()
        add_new_val = (v == 'true')
    label_add = 'Авто-добавление групп: ' + ('✅' if add_new_val else '❌')
    time_hold_path = os.path.join(base, 'time_hold.txt')
    if os.path.exists(time_hold_path):
        try:
            txt = open(time_hold_path, encoding='utf-8').read().strip()
            parts = [p.strip() for p in txt.split(',')]
            if len(parts) == 2:
                mn, mx = parts
                label_time = f"Задержки (сек): [{mn}–{mx}]"
            else:
                label_time = "Задержки: неверный формат"
        except:
            label_time = "Задержки: ошибка чтения"
    else:
        label_time = "Задержки: не заданы"
    file_labels = {
        'channel.txt': '📋 Статические группы',
        'joined_groups.txt': '🔁 Авто-добавленные группы',
        'template.txt': '💬 Ответ на упоминание',
        'template_private.txt': '🔐 Ответ в ЛС',
        'template_group.txt': '📢 Текст для рассылки',
        'num_of_channels.txt': '🔢 Макс групп (0–1000)',
    }
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton(label_add, callback_data=f"toggle_addnew:{folder}"))
    kb.add(types.InlineKeyboardButton(label_time, callback_data=f"timehold:{folder}"))
    for fn, lab in file_labels.items():
        kb.add(types.InlineKeyboardButton(lab, callback_data=f"file_sel:{fn}:{folder}"))
    kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_folder_files"))
    set_state(user_id, S_FOLDER_FILE_SELECT)
    USER_STATE[user_id]['folder'] = folder
    bot.send_message(chat_id, f"📁 Папка: `{folder}`\nВыберите действие:", reply_markup=kb, parse_mode='Markdown')


@bot.message_handler(commands=['start'])
@ensure_db
def cmd_start(m):
    send_main_menu(m.chat.id, m.from_user.id)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_MAIN)
def main_menu(m):
    user_id = m.from_user.id
    text = m.text
    if text == '➕ Добавить аккаунт':
        set_state(user_id, S_ADD_ACCOUNT_PHONE)
        bot.send_message(m.chat.id, "Введите номер телефона (в международном формате):",
                         reply_markup=make_cancel_keyboard())
    elif text == '✏️ Редактировать аккаунт':
        send_edit_menu(m.chat.id, user_id)
    elif text == '🗑 Удалить аккаунт':
        send_delete_menu(m.chat.id, user_id)
    elif text == '📂 Управление папками':
        send_folder_menu(m.chat.id, user_id)
    elif text == '📝 Логи':
        bot.send_message(m.chat.id, "Логи выводятся в консоль запуска бота.")
    elif text == '⚙️ Запустить/Остановить бота':
        kb = types.InlineKeyboardMarkup()
        kb.add(
            types.InlineKeyboardButton("▶️ Запустить", callback_data="bot:start"),
            types.InlineKeyboardButton("⏹ Остановить", callback_data="bot:stop"),
        )
        kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_main"))
        bot.send_message(m.chat.id, "Управление ботом:", reply_markup=kb)
    else:
        bot.send_message(m.chat.id, "Пожалуйста, выберите пункт меню.")


# Добавление аккаунта
@bot.message_handler(func=lambda m: get_state(m.from_user.id) in (
        S_ADD_ACCOUNT_PHONE, S_ADD_ACCOUNT_API_ID, S_ADD_ACCOUNT_API_HASH,
        S_ADD_ACCOUNT_SESSION, S_ADD_ACCOUNT_FOLDER, S_ADD_ACCOUNT_CODE, S_ADD_ACCOUNT_2FA
) and m.text == "Отмена")
def add_account_cancel(m):
    user_id = m.from_user.id
    bot.send_message(m.chat.id, "Добавление аккаунта отменено.", reply_markup=types.ReplyKeyboardRemove())
    send_main_menu(m.chat.id, user_id)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_PHONE)
def add_account_phone(m):
    user_id = m.from_user.id
    phone = m.text.strip()
    USER_STATE[user_id] = {'state': S_ADD_ACCOUNT_PHONE, 'phone': phone}
    set_state(user_id, S_ADD_ACCOUNT_API_ID)
    bot.send_message(m.chat.id, "Введите API_ID:", reply_markup=make_cancel_keyboard())


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_API_ID)
def add_account_api_id(m):
    user_id = m.from_user.id
    try:
        api_id = int(m.text.strip())
    except ValueError:
        bot.send_message(m.chat.id, "API_ID должен быть числом. Попробуйте ещё раз:",
                         reply_markup=make_cancel_keyboard())
        return
    USER_STATE[user_id].update({'api_id': api_id})
    set_state(user_id, S_ADD_ACCOUNT_API_HASH)
    bot.send_message(m.chat.id, "Введите API_HASH:", reply_markup=make_cancel_keyboard())


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_API_HASH)
def add_account_api_hash(m):
    user_id = m.from_user.id
    api_hash = m.text.strip()
    USER_STATE[user_id].update({'api_hash': api_hash})
    set_state(user_id, S_ADD_ACCOUNT_SESSION)
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    kb.add("Оставить пустым", "Отмена")
    bot.send_message(m.chat.id, "Введите StringSession (или нажмите «Оставить пустым»):", reply_markup=kb)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_SESSION)
@ensure_db
def add_account_session(m):
    user_id = m.from_user.id
    text = m.text.strip()
    if text == "Отмена":
        bot.send_message(m.chat.id, "Добавление аккаунта отменено.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    if text == "Оставить пустым":
        text = ""
    USER_STATE[user_id].update({'ss': text})
    folders = [d for d in os.listdir(FOLDERS_DIR) if os.path.isdir(os.path.join(FOLDERS_DIR, d))]
    if not folders:
        bot.send_message(m.chat.id, "Нет доступных папок. Сначала создайте папку через меню «Управление папками».",
                         reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    list_text = "Доступные папки:\n" + "\n".join(f"- {f}" for f in folders)
    bot.send_message(m.chat.id, list_text)
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    for f in folders:
        kb.add(f)
    kb.add("Отмена")
    set_state(user_id, S_ADD_ACCOUNT_FOLDER)
    bot.send_message(m.chat.id, "Введите имя папки из списка или нажмите Отмена:", reply_markup=kb)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_FOLDER)
@ensure_db
def add_account_folder(m):
    user_id = m.from_user.id
    text = m.text.strip()
    if text == "Отмена":
        bot.send_message(m.chat.id, "Добавление аккаунта отменено.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    folders = [d for d in os.listdir(FOLDERS_DIR) if os.path.isdir(os.path.join(FOLDERS_DIR, d))]
    if text not in folders:
        list_text = "Доступные папки:\n" + "\n".join(f"- {f}" for f in folders)
        bot.send_message(m.chat.id, list_text)
        kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        for f in folders:
            kb.add(f)
        kb.add("Отмена")
        return bot.send_message(m.chat.id, "Неверный выбор. Введите имя папки из списка или Отмена:", reply_markup=kb)
    folder = text
    USER_STATE[user_id].update({'folder': folder})
    phone = USER_STATE[user_id].get('phone')
    api_id = USER_STATE[user_id].get('api_id')
    api_hash = USER_STATE[user_id].get('api_hash')
    ss = USER_STATE[user_id].get('ss', '')
    if ss:
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            with SyncTelegramClient(StringSession(ss), api_id, api_hash) as client:
                client.get_me()
            add_account(phone if phone else None, api_id, api_hash, ss, int(folder))
            bot.send_message(m.chat.id, "Аккаунт добавлен с указанной StringSession ✅",
                             reply_markup=types.ReplyKeyboardRemove())
            return send_main_menu(m.chat.id, user_id)
        except Exception as e:
            bot.send_message(m.chat.id, f"⚠️ StringSession недействителен: {e}. Будем входить по телефону.",
                             reply_markup=types.ReplyKeyboardRemove())
            USER_STATE[user_id]['ss'] = ''
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        client = SyncTelegramClient(StringSession(), api_id, api_hash)
        client.connect()
        bot.send_message(m.chat.id, f"📲 Отправляем код на номер {phone}...", reply_markup=types.ReplyKeyboardRemove())
        client.send_code_request(phone)
        USER_STATE[user_id]['tg_client'] = client
        USER_STATE[user_id]['loop'] = loop
        set_state(user_id, S_ADD_ACCOUNT_CODE)
        bot.send_message(m.chat.id, "Введите код из Telegram:", reply_markup=make_cancel_keyboard())
    except FloodWaitError as fw:
        bot.send_message(m.chat.id, f"Ошибка: слишком частые запросы. Попробуйте позже. {fw}",
                         reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    except Exception as e:
        bot.send_message(m.chat.id, f"❌ Ошибка при отправке кода: {e}", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_CODE)
def add_account_code(m):
    user_id = m.from_user.id
    text = m.text.strip()
    if text == "Отмена":
        client = USER_STATE[user_id].get('tg_client')
        loop = USER_STATE[user_id].get('loop')
        if client:
            try:
                client.disconnect()
            except:
                pass
        if loop:
            try:
                loop.close()
            except:
                pass
        bot.send_message(m.chat.id, "Добавление аккаунта отменено.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    USER_STATE[user_id].update({'code': text})
    client = USER_STATE[user_id].get('tg_client')
    loop = USER_STATE[user_id].get('loop')
    phone = USER_STATE[user_id].get('phone')
    api_id = USER_STATE[user_id].get('api_id')
    api_hash = USER_STATE[user_id].get('api_hash')
    folder = USER_STATE[user_id].get('folder')
    if not client or not loop:
        bot.send_message(m.chat.id, "Внутренняя ошибка: клиент не найден.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    try:
        asyncio.set_event_loop(loop)
        client.sign_in(phone=phone, code=text)
    except SessionPasswordNeededError:
        set_state(user_id, S_ADD_ACCOUNT_2FA)
        bot.send_message(m.chat.id, "🔐 Введите 2FA-пароль:", reply_markup=make_cancel_keyboard())
        return
    except PhoneCodeInvalidError:
        bot.send_message(m.chat.id, "❌ Неверный код. Попробуйте ещё раз или нажмите Отмена:",
                         reply_markup=make_cancel_keyboard())
        return
    except PhoneCodeExpiredError:
        bot.send_message(m.chat.id, "❌ Код истёк. Начните заново.", reply_markup=types.ReplyKeyboardRemove())
        try:
            client.disconnect()
        except:
            pass
        try:
            loop.close()
        except:
            pass
        return send_main_menu(m.chat.id, user_id)
    except FloodWaitError as fw:
        bot.send_message(m.chat.id, f"Слишком частые попытки: {fw}", reply_markup=types.ReplyKeyboardRemove())
        try:
            client.disconnect()
        except:
            pass
        try:
            loop.close()
        except:
            pass
        return send_main_menu(m.chat.id, user_id)
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка при входе с кодом: {e}", reply_markup=types.ReplyKeyboardRemove())
        try:
            client.disconnect()
        except:
            pass
        try:
            loop.close()
        except:
            pass
        return send_main_menu(m.chat.id, user_id)
    try:
        new_ss = client.session.save()
        client.disconnect()
        try:
            loop.close()
        except:
            pass
        add_account(phone, api_id, api_hash, new_ss, int(folder))
        bot.send_message(m.chat.id, f"Аккаунт успешно авторизован и добавлен ✅\nStringSession: `{new_ss}`",
                         parse_mode='Markdown', reply_markup=types.ReplyKeyboardRemove())
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка при сохранении сессии: {e}", reply_markup=types.ReplyKeyboardRemove())
    return send_main_menu(m.chat.id, user_id)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_ADD_ACCOUNT_2FA)
def add_account_2fa(m):
    user_id = m.from_user.id
    text = m.text.strip()
    if text == "Отмена":
        client = USER_STATE[user_id].get('tg_client')
        loop = USER_STATE[user_id].get('loop')
        if client:
            try:
                client.disconnect()
            except:
                pass
        if loop:
            try:
                loop.close()
            except:
                pass
        bot.send_message(m.chat.id, "Добавление аккаунта отменено.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    client = USER_STATE[user_id].get('tg_client')
    loop = USER_STATE[user_id].get('loop')
    phone = USER_STATE[user_id].get('phone')
    api_id = USER_STATE[user_id].get('api_id')
    api_hash = USER_STATE[user_id].get('api_hash')
    folder = USER_STATE[user_id].get('folder')
    if not client or not loop:
        bot.send_message(m.chat.id, "Внутренняя ошибка: клиент не найден.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    try:
        asyncio.set_event_loop(loop)
        client.sign_in(password=text)
    except Exception as e:
        bot.send_message(m.chat.id, f"❌ Неверный 2FA: {e}. Попробуйте ещё раз или Отмена:",
                         reply_markup=make_cancel_keyboard())
        return
    try:
        new_ss = client.session.save()
        client.disconnect()
        try:
            loop.close()
        except:
            pass
        add_account(phone, api_id, api_hash, new_ss, int(folder))
        bot.send_message(m.chat.id, f"Аккаунт авторизован и добавлен ✅\nStringSession: `{new_ss}`",
                         parse_mode='Markdown', reply_markup=types.ReplyKeyboardRemove())
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка при сохранении сессии: {e}", reply_markup=types.ReplyKeyboardRemove())
    return send_main_menu(m.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('edit_sel:'))
@ensure_db
def callback_edit_select(cb):
    user_id = cb.from_user.id
    acc_id = int(cb.data.split(':', 1)[1])
    USER_STATE[user_id] = {'state': S_EDIT_SELECT, 'edit_id': acc_id}
    bot.answer_callback_query(cb.id)
    send_field_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data == 'cancel_edit_select')
def callback_cancel_edit_select(cb):
    user_id = cb.from_user.id
    bot.answer_callback_query(cb.id, "Отмена")
    bot.send_message(cb.message.chat.id, "Редактирование аккаунта отменено.")
    send_main_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('edit_field:'))
def callback_edit_field(cb):
    user_id = cb.from_user.id
    field = cb.data.split(':', 1)[1]
    USER_STATE[user_id]['edit_field'] = field
    bot.answer_callback_query(cb.id)
    if field == 'folder_number':
        folders = [d for d in os.listdir(FOLDERS_DIR) if os.path.isdir(os.path.join(FOLDERS_DIR, d))]
        if not folders:
            bot.send_message(cb.message.chat.id, "Нет доступных папок.", reply_markup=types.ReplyKeyboardRemove())
            return send_field_menu(cb.message.chat.id, user_id)
        list_text = "Доступные папки:\n" + "\n".join(f"- {f}" for f in folders)
        bot.send_message(cb.message.chat.id, list_text)
        kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        for f in folders:
            kb.add(f)
        kb.add("Отмена")
        set_state(user_id, S_EDIT_VALUE)
        bot.send_message(cb.message.chat.id, "Введите имя папки из списка или Отмена:", reply_markup=kb)
    else:
        label = FIELD_LABELS.get(field, field)
        kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        kb.add("Отмена")
        set_state(user_id, S_EDIT_VALUE)
        bot.send_message(cb.message.chat.id, f"Введите новое значение для «{label}» или Отмена:", reply_markup=kb)


@bot.callback_query_handler(func=lambda cb: cb.data == 'cancel_edit_fields')
def callback_cancel_edit_fields(cb):
    user_id = cb.from_user.id
    bot.answer_callback_query(cb.id, "Отмена")
    bot.send_message(cb.message.chat.id, "Редактирование полей отменено.")
    send_edit_menu(cb.message.chat.id, user_id)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_EDIT_VALUE)
@ensure_db
def edit_value(m):
    user_id = m.from_user.id
    text = m.text.strip()
    field = USER_STATE.get(user_id, {}).get('edit_field')
    acc_id = USER_STATE.get(user_id, {}).get('edit_id')
    if field is None or acc_id is None:
        bot.send_message(m.chat.id, "Ошибка состояния. Возвращаем в главное.", reply_markup=types.ReplyKeyboardRemove())
        return send_main_menu(m.chat.id, user_id)
    if text == "Отмена":
        bot.send_message(m.chat.id, "Редактирование отменено.", reply_markup=types.ReplyKeyboardRemove())
        return send_field_menu(m.chat.id, user_id)
    if field == 'folder_number':
        folders = [d for d in os.listdir(FOLDERS_DIR) if os.path.isdir(os.path.join(FOLDERS_DIR, d))]
        if text not in folders:
            list_text = "Доступные папки:\n" + "\n".join(f"- {f}" for f in folders)
            bot.send_message(m.chat.id, list_text)
            kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            for f in folders:
                kb.add(f)
            kb.add("Отмена")
            return bot.send_message(m.chat.id, "Неверный выбор. Введите имя папки из списка или Отмена:",
                                    reply_markup=kb)
        try:
            new_num = int(text)
        except ValueError:
            bot.send_message(m.chat.id, "Имя папки должно быть числом.", reply_markup=types.ReplyKeyboardRemove())
            return send_field_menu(m.chat.id, user_id)
        try:
            update_account(acc_id, folder_number=new_num)
            bot.send_message(m.chat.id, f"Номер папки обновлён на {new_num} ✅",
                             reply_markup=types.ReplyKeyboardRemove())
        except Exception as e:
            bot.send_message(m.chat.id, f"Ошибка: {e}", reply_markup=types.ReplyKeyboardRemove())
        return send_field_menu(m.chat.id, user_id)
    if field == 'api_id':
        try:
            val = int(text)
        except ValueError:
            return bot.send_message(m.chat.id, "API ID должен быть числом. Попробуйте ещё раз или Отмена:",
                                    reply_markup=make_cancel_keyboard())
        kwargs = {'api_id': val}
    elif field == 'phone':
        kwargs = {'phone': text}
    elif field == 'api_hash':
        kwargs = {'api_hash': text}
    elif field == 'string_session':
        kwargs = {'string_session': text}
    else:
        bot.send_message(m.chat.id, "Неизвестное поле.", reply_markup=types.ReplyKeyboardRemove())
        return send_field_menu(m.chat.id, user_id)
    try:
        update_account(acc_id, **kwargs)
        label = FIELD_LABELS.get(field, field)
        bot.send_message(m.chat.id, f"Значение «{label}» обновлено ✅", reply_markup=types.ReplyKeyboardRemove())
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка: {e}", reply_markup=types.ReplyKeyboardRemove())
    return send_field_menu(m.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('delete_sel:'))
@ensure_db
def callback_delete_select(cb):
    user_id = cb.from_user.id
    acc_id = int(cb.data.split(':', 1)[1])
    bot.answer_callback_query(cb.id)
    try:
        delete_account(acc_id)
        bot.edit_message_text(f"Аккаунт ID {acc_id} удалён ✅", cb.message.chat.id, cb.message.message_id)
    except Exception as e:
        bot.edit_message_text(f"Ошибка при удалении: {e}", cb.message.chat.id, cb.message.message_id)
    accounts = get_accounts()
    if accounts:
        send_delete_menu(cb.message.chat.id, user_id)
    else:
        bot.send_message(cb.message.chat.id, "Нет больше аккаунтов.")
        send_main_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data == 'cancel_delete')
def callback_cancel_delete(cb):
    user_id = cb.from_user.id
    bot.answer_callback_query(cb.id, "Отмена")
    bot.send_message(cb.message.chat.id, "Удаление аккаунта отменено.")
    send_main_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('bot:'))
def callback_bot(cb):
    user_id = cb.from_user.id
    action = cb.data.split(':', 1)[1]
    bot.answer_callback_query(cb.id)
    if action == 'start':
        start_bot()
        bot.send_message(cb.message.chat.id, "Бот запущен.")
    else:
        stop_bot()
        bot.send_message(cb.message.chat.id, "Бот остановлен.")
    send_main_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data == 'cancel_folder')
def callback_cancel_folder(cb):
    user_id = cb.from_user.id
    bot.answer_callback_query(cb.id, "Отмена")
    bot.send_message(cb.message.chat.id, "Управление папками отменено.")
    send_main_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data == 'cancel_folder_files')
def callback_cancel_folder_files(cb):
    user_id = cb.from_user.id
    bot.answer_callback_query(cb.id, "Отмена")
    bot.send_message(cb.message.chat.id, "Действие отменено.")
    send_folder_menu(cb.message.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data == 'folder_new')
def callback_folder_new(cb):
    user_id = cb.from_user.id
    bot.answer_callback_query(cb.id)
    set_state(user_id, S_FOLDER_NEW)
    bot.send_message(cb.message.chat.id, "Отправьте название новой папки:", reply_markup=make_cancel_keyboard())


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_FOLDER_NEW)
def folder_new(m):
    user_id = m.from_user.id
    name = m.text.strip()
    if name == "Отмена":
        bot.send_message(m.chat.id, "Создание папки отменено.", reply_markup=types.ReplyKeyboardRemove())
        return send_folder_menu(m.chat.id, user_id)
    path = os.path.join(FOLDERS_DIR, name)
    try:
        os.makedirs(path, exist_ok=True)
        for fn in (
                'channel.txt', 'joined_groups.txt',
                'template.txt', 'template_private.txt',
                'template_group.txt', 'ADD_NEW_CHANNELS.txt',
                'num_of_channels.txt', 'time_hold.txt'
        ):
            open(os.path.join(path, fn), 'a', encoding='utf-8').close()
        with open(os.path.join(path, 'ADD_NEW_CHANNELS.txt'), 'w', encoding='utf-8') as f:
            f.write('False')
        bot.send_message(m.chat.id, f"Папка «{name}» создана.", reply_markup=types.ReplyKeyboardRemove())
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка при создании папки: {e}", reply_markup=types.ReplyKeyboardRemove())
    return send_folder_menu(m.chat.id, user_id)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('folder_sel:'))
def callback_folder_select(cb):
    user_id = cb.from_user.id
    folder = cb.data.split(':', 1)[1]
    bot.answer_callback_query(cb.id)
    send_folder_files_menu(cb.message.chat.id, user_id, folder)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('toggle_addnew:'))
def callback_toggle_addnew(cb):
    user_id = cb.from_user.id
    folder = cb.data.split(':', 1)[1]
    base = os.path.join(FOLDERS_DIR, folder)
    path = os.path.join(base, 'ADD_NEW_CHANNELS.txt')
    current = False
    if os.path.exists(path):
        v = open(path, encoding='utf-8').read().strip().lower()
        current = (v == 'true')
    new = not current
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write('True' if new else 'False')
        bot.answer_callback_query(cb.id, f"Авто-добавление групп {'включено' if new else 'выключено'}")
    except Exception as e:
        bot.answer_callback_query(cb.id, f"Ошибка: {e}")
        return
    add_new_val = new
    label_add = 'Авто-добавление групп: ' + ('✅' if add_new_val else '❌')
    time_hold_path = os.path.join(base, 'time_hold.txt')
    if os.path.exists(time_hold_path):
        try:
            txt = open(time_hold_path, encoding='utf-8').read().strip()
            parts = [p.strip() for p in txt.split(',')]
            if len(parts) == 2:
                mn, mx = parts
                label_time = f"Задержки (сек): [{mn}–{mx}]"
            else:
                label_time = "Задержки: неверный формат"
        except:
            label_time = "Задержки: ошибка чтения"
    else:
        label_time = "Задержки: не заданы"
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton(label_add, callback_data=f"toggle_addnew:{folder}"))
    kb.add(types.InlineKeyboardButton(label_time, callback_data=f"timehold:{folder}"))
    file_labels = {
        'channel.txt': '📋 Статические группы',
        'joined_groups.txt': '🔁 Авто-добавленные группы',
        'template.txt': '💬 Ответ на упоминание',
        'template_private.txt': '🔐 Ответ в ЛС',
        'template_group.txt': '📢 Текст для рассылки',
        'num_of_channels.txt': '🔢 Макс групп (0–1000)',
    }
    for fn, lab in file_labels.items():
        kb.add(types.InlineKeyboardButton(lab, callback_data=f"file_sel:{fn}:{folder}"))
    kb.add(types.InlineKeyboardButton("❌ Отмена", callback_data="cancel_folder_files"))
    text = f"📁 Папка: `{folder}`\nВыберите действие:"
    try:
        bot.edit_message_text(chat_id=cb.message.chat.id, message_id=cb.message.message_id,
                              text=text, parse_mode='Markdown', reply_markup=kb)
    except:
        bot.send_message(cb.message.chat.id, text, parse_mode='Markdown', reply_markup=kb)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('timehold:'))
def callback_timehold(cb):
    user_id = cb.from_user.id
    folder = cb.data.split(':', 1)[1]
    base = os.path.join(FOLDERS_DIR, folder)
    path = os.path.join(base, 'time_hold.txt')
    if os.path.exists(path):
        cur = open(path, encoding='utf-8').read().strip()
    else:
        cur = ''
    bot.answer_callback_query(cb.id)
    if cur:
        bot.send_message(cb.message.chat.id, f"Текущие задержки (min,max в секундах): {cur}")
    else:
        bot.send_message(cb.message.chat.id, "Задержки пока не заданы.")
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    kb.add("Отмена")
    USER_STATE[user_id].update({'folder_timehold': folder})
    set_state(user_id, S_FOLDER_TIMEHOLD_EDIT)
    bot.send_message(cb.message.chat.id, "Введите новые задержки в формате min,max или нажмите Отмена:",
                     reply_markup=kb)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_FOLDER_TIMEHOLD_EDIT)
def handle_timehold_edit(m):
    user_id = m.from_user.id
    text = m.text.strip()
    folder = USER_STATE.get(user_id, {}).get('folder_timehold')
    if text == "Отмена" or folder is None:
        bot.send_message(m.chat.id, "Настройка задержек отменена.", reply_markup=types.ReplyKeyboardRemove())
        return send_folder_files_menu(m.chat.id, user_id, folder or '')
    parts = [p.strip() for p in text.split(',')]
    if len(parts) != 2:
        bot.send_message(m.chat.id, "Неверный формат. Введите min,max или Отмена:", reply_markup=make_cancel_keyboard())
        return
    try:
        mn = float(parts[0]);
        mx = float(parts[1])
        if mn < 0 or mx < 0 or mn > mx:
            raise ValueError
    except:
        bot.send_message(m.chat.id, "Неверные числа. Убедитесь, что 0 ≤ min ≤ max. Попробуйте снова или Отмена:",
                         reply_markup=make_cancel_keyboard())
        return
    path = os.path.join(FOLDERS_DIR, folder, 'time_hold.txt')
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(f"{mn},{mx}")
        bot.send_message(m.chat.id, f"Задержки сохранены: {mn}–{mx} сек.", reply_markup=types.ReplyKeyboardRemove())
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка при сохранении: {e}", reply_markup=types.ReplyKeyboardRemove())
    return send_folder_files_menu(m.chat.id, user_id, folder)


@bot.callback_query_handler(func=lambda cb: cb.data.startswith('file_sel:'))
def callback_file_select(cb):
    user_id = cb.from_user.id
    _, fname, folder = cb.data.split(':', 2)
    bot.answer_callback_query(cb.id)
    base = os.path.join(FOLDERS_DIR, folder)
    path = os.path.join(base, fname)
    if os.path.exists(path):
        try:
            current_text = open(path, encoding='utf-8').read().strip()
        except:
            current_text = ''
    else:
        current_text = ''
    USER_STATE[user_id]['edit_file'] = fname
    USER_STATE[user_id]['folder'] = folder
    set_state(user_id, S_FOLDER_FILE_EDIT)
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    kb.add("Отмена")
    msg = f"Редактирование `{fname}` в папке `{folder}`.\nТекущее содержимое:\n```\n{current_text[:4000]}\n```"
    bot.send_message(cb.message.chat.id, msg, parse_mode='Markdown')
    bot.send_message(cb.message.chat.id, "Отправьте новый текст (либо ссылку addlist) или нажмите Отмена:",
                     reply_markup=kb)


@bot.message_handler(func=lambda m: get_state(m.from_user.id) == S_FOLDER_FILE_EDIT)
def save_file_content(m):
    user_id = m.from_user.id
    text = m.text.strip()
    if text == "Отмена":
        bot.send_message(m.chat.id, "Редактирование файла отменено.", reply_markup=types.ReplyKeyboardRemove())
        folder = USER_STATE.get(user_id, {}).get('folder')
        return send_folder_files_menu(m.chat.id, user_id, folder or '')
    folder = USER_STATE.get(user_id, {}).get('folder')
    fname = USER_STATE.get(user_id, {}).get('edit_file')
    if not folder or not fname:
        return send_folder_menu(m.chat.id, user_id)
    path = os.path.join(FOLDERS_DIR, folder, fname)
    addlist_hash = None
    m0 = re.search(r'(?:https?://)?t\.me/addlist/([\w\d_-]+)', text)
    if m0:
        addlist_hash = m0.group(1)
    if addlist_hash:
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(text + '\n')
            bot.send_message(m.chat.id, f"Ссылка addlist сохранена в `{fname}`.", parse_mode='Markdown',
                             reply_markup=types.ReplyKeyboardRemove())
        except Exception as e:
            bot.send_message(m.chat.id, f"Ошибка при сохранении ссылки: {e}", reply_markup=types.ReplyKeyboardRemove())
        return send_folder_files_menu(m.chat.id, user_id, folder)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(text)
        bot.send_message(m.chat.id, f"✅ Файл `{fname}` обновлён.", parse_mode='Markdown',
                         reply_markup=types.ReplyKeyboardRemove())
    except Exception as e:
        bot.send_message(m.chat.id, f"Ошибка при сохранении файла: {e}", reply_markup=types.ReplyKeyboardRemove())
    return send_folder_files_menu(m.chat.id, user_id, folder)


if __name__ == '__main__':
    print("Bot started...")
    bot.infinity_polling(none_stop=True)
