# gui.py
import asyncio
import datetime
import os
import shutil
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, simpledialog, filedialog

from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError
from telethon.sessions import StringSession

from bot_script import (
    init_db, add_account,
    update_account, delete_account,
    start_bot, stop_bot
)

DB_PATH = 'accounts.db'
FOLDERS_DIR = 'folders'


class BotGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Telegram Bot Manager")
        self.geometry("1200x650")
        os.makedirs(FOLDERS_DIR, exist_ok=True)
        init_db()
        self._build_ui()

    def _build_ui(self):
        notebook = ttk.Notebook(self)
        notebook.pack(fill='both', expand=True)

        self._build_accounts_tab(notebook)
        self._build_folders_tab(notebook)

    # ─── Accounts Tab ───
    def _build_accounts_tab(self, parent):
        frame = ttk.Frame(parent)
        parent.add(frame, text="Аккаунты")

        # Таблица аккаунтов
        cols = ("id", "phone", "api_id", "api_hash", "string_session", "folder")
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="browse")
        for c in cols:
            self.tree.heading(c, text=c.capitalize())
            self.tree.column(c, width=120, anchor='center')
        self.tree.pack(fill='both', padx=5, pady=5)
        self.tree.bind("<<TreeviewSelect>>", self._on_account_select)

        # Форма ввода/редактирования
        form = ttk.Frame(frame)
        form.pack(fill='x', padx=5, pady=5)
        for i in range(4):
            form.columnconfigure(i, weight=1)

        self.var_type = tk.StringVar(value='phone')
        ttk.Radiobutton(form, text="Вход по телефону", variable=self.var_type, value='phone',
                        command=self._update_fields).grid(row=0, column=0, sticky='w')
        ttk.Radiobutton(form, text="Вход по StringSession", variable=self.var_type, value='ss',
                        command=self._update_fields).grid(row=0, column=1, sticky='w')

        ttk.Label(form, text="Номер телефона:").grid(row=1, column=0, sticky='e')
        self.ent_phone = ttk.Entry(form)
        self.ent_phone.grid(row=1, column=1, sticky='we', padx=5)
        ttk.Label(form, text="API_ID:").grid(row=2, column=0, sticky='e')
        self.ent_api_id = ttk.Entry(form)
        self.ent_api_id.grid(row=2, column=1, sticky='we', padx=5)
        ttk.Label(form, text="API_HASH:").grid(row=2, column=2, sticky='e')
        self.ent_api_hash = ttk.Entry(form)
        self.ent_api_hash.grid(row=2, column=3, sticky='we', padx=5)
        ttk.Label(form, text="StringSession:").grid(row=3, column=0, sticky='e')
        self.ent_ss = ttk.Entry(form)
        self.ent_ss.grid(row=3, column=1, columnspan=3, sticky='we', padx=5)
        ttk.Label(form, text="Номер папки:").grid(row=4, column=0, sticky='e')
        self.cmb_folder = ttk.Combobox(form, values=self._list_folders(), state='readonly')
        self.cmb_folder.grid(row=4, column=1, sticky='we', padx=5)

        # Кнопки управления
        btns = ttk.Frame(frame)
        btns.pack(fill='x', pady=10)
        self.btn_add = ttk.Button(btns, text="Добавить аккаунт", command=self._add_account)
        self.btn_add.pack(side='left', padx=5)
        self.btn_save = ttk.Button(btns, text="Сохранить изменения", command=self._save_account)
        self.btn_save.pack(side='left', padx=5)
        self.btn_delete = ttk.Button(btns, text="Удалить аккаунт", command=self._delete_account)
        self.btn_delete.pack(side='left', padx=5)
        self.btn_cancel = ttk.Button(btns, text="Отменить редактирование", command=self._cancel_edit)
        self.btn_cancel.pack(side='left', padx=5)
        ttk.Button(btns, text="Запустить бота", command=start_bot).pack(side='left', padx=20)
        ttk.Button(btns, text="Остановить бота", command=stop_bot).pack(side='left', padx=5)
        ttk.Button(btns, text="Создать резервную копию БД", command=self._backup_db).pack(side='left', padx=5)
        ttk.Button(btns, text="Восстановить из резервной копии", command=self._restore_db).pack(side='left', padx=5)

        # Инициализация
        self._update_fields()
        self._load_accounts()
        self._cancel_edit()

    def _list_folders(self):
        return sorted(d for d in os.listdir(FOLDERS_DIR)
                      if os.path.isdir(os.path.join(FOLDERS_DIR, d)))

    def _update_fields(self):
        if self.var_type.get() == 'phone':
            self.ent_phone.config(state='normal')
            self.ent_ss.config(state='disabled')
        else:
            self.ent_phone.config(state='normal')
            self.ent_ss.config(state='normal')

    def _backup_db(self):
        if not os.path.exists(DB_PATH):
            messagebox.showwarning("Ошибка", "Файл базы данных не найден.")
            return
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = f"accounts_backup_{ts}.db"
        try:
            shutil.copyfile(DB_PATH, backup_path)
            messagebox.showinfo("Успех", f"Резервная копия сохранена как:\n{backup_path}")
        except Exception as e:
            messagebox.showerror("Ошибка копирования", f"Не удалось создать резервную копию:\n{e}")

    def _restore_db(self):
        fname = filedialog.askopenfilename(
            title="Выберите файл резервной копии",
            filetypes=[("SQLite БД", "*.db"), ("Все файлы", "*.*")]
        )
        if not fname:
            return
        try:
            shutil.copyfile(fname, DB_PATH)
            messagebox.showinfo("Успех", "База данных успешно восстановлена.")
            self._load_accounts()
        except Exception as e:
            messagebox.showerror("Ошибка восстановления", f"Не удалось восстановить БД:\n{e}")

    def _load_accounts(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute('SELECT id,phone,api_id,api_hash,string_session,folder_number FROM accounts')
        for rec in cur.fetchall():
            self.tree.insert("", "end", values=rec)
        conn.close()

    def _on_account_select(self, _):
        sel = self.tree.selection()
        if not sel:
            return
        acc_id, phone, aid, ahash, ss, folder = self.tree.item(sel[0], 'values')

        self.var_type.set('phone' if phone else 'ss')
        self.ent_phone.config(state='normal')
        self.ent_phone.delete(0, tk.END)
        if phone:
            self.ent_phone.insert(0, phone)
        self.ent_api_id.delete(0, tk.END)
        self.ent_api_id.insert(0, aid)
        self.ent_api_hash.delete(0, tk.END)
        self.ent_api_hash.insert(0, ahash)
        self.ent_ss.config(state='normal')
        self.ent_ss.delete(0, tk.END)
        if ss:
            self.ent_ss.insert(0, ss)
        self.cmb_folder.set(str(folder))
        self._update_fields()

        self.btn_add.state(['disabled'])
        self.btn_save.state(['!disabled'])
        self.btn_delete.state(['!disabled'])
        self.btn_cancel.state(['!disabled'])

    def _add_account(self):
        mode = self.var_type.get()
        try:
            folder = int(self.cmb_folder.get())
        except ValueError:
            messagebox.showerror("Ошибка", "Выберите корректный номер папки.")
            return

        try:
            api_id = int(self.ent_api_id.get())
        except ValueError:
            messagebox.showerror("Ошибка", "API_ID должен быть числом.")
            return

        if mode == 'phone':
            phone = self.ent_phone.get().strip()
            api_hash = self.ent_api_hash.get().strip()

            async def do_login():
                client = TelegramClient(StringSession(), api_id, api_hash)
                await client.connect()
                await client.send_code_request(phone)
                code = simpledialog.askstring("Код подтверждения",
                                              f"Введите SMS-код для {phone}:")
                try:
                    await client.sign_in(phone=phone, code=code)
                except SessionPasswordNeededError:
                    pwd = simpledialog.askstring("2FA-пароль",
                                                 "Введите двухфакторный пароль:",
                                                 show='*')
                    await client.sign_in(password=pwd)
                session_str = client.session.save()
                await client.disconnect()
                return session_str

            try:
                session = asyncio.run(do_login())
            except Exception as e:
                messagebox.showerror("Ошибка входа", str(e))
                return

            phone_db = phone or None
            ss_db = session
        else:
            phone_db = self.ent_phone.get().strip() or None
            api_hash = self.ent_api_hash.get().strip()
            ss_db = self.ent_ss.get().strip()
            if not ss_db:
                messagebox.showerror("Ошибка", "StringSession не может быть пустым.")
                return

        add_account(phone_db, api_id, api_hash, ss_db, folder)
        messagebox.showinfo("Успех", "Аккаунт успешно добавлен.")
        self._load_accounts()
        self._cancel_edit()

    def _save_account(self):
        sel = self.tree.selection()
        if not sel:
            return
        acc_id = self.tree.item(sel[0], 'values')[0]
        try:
            api_id = int(self.ent_api_id.get())
        except ValueError:
            messagebox.showerror("Ошибка", "API_ID должен быть числом.")
            return

        phone = self.ent_phone.get().strip() or None
        api_hash = self.ent_api_hash.get().strip()
        ss = self.ent_ss.get().strip() if self.var_type.get() == 'ss' else None
        try:
            folder = int(self.cmb_folder.get())
        except ValueError:
            messagebox.showerror("Ошибка", "Выберите корректный номер папки.")
            return

        update_account(acc_id, phone, api_id, api_hash, ss, folder)
        messagebox.showinfo("Успех", "Изменения успешно сохранены.")
        self._load_accounts()
        self._cancel_edit()

    def _delete_account(self):
        sel = self.tree.selection()
        if not sel:
            return
        acc_id = self.tree.item(sel[0], 'values')[0]
        if messagebox.askyesno("Подтверждение", "Вы уверены, что хотите удалить этот аккаунт?"):
            delete_account(acc_id)
            self._load_accounts()
            self._cancel_edit()

    def _cancel_edit(self):
        self.tree.selection_remove(self.tree.selection())
        for w in (self.ent_phone, self.ent_api_id, self.ent_api_hash, self.ent_ss):
            w.delete(0, tk.END)
        self.cmb_folder.set('')
        self.var_type.set('phone')
        self._update_fields()

        self.btn_add.state(['!disabled'])
        self.btn_save.state(['disabled'])
        self.btn_delete.state(['disabled'])
        self.btn_cancel.state(['disabled'])

    # ─── Folders Tab ───
    def _build_folders_tab(self, parent):
        frame = ttk.Frame(parent)
        parent.add(frame, text="Папки")

        left = ttk.Frame(frame)
        left.pack(side='left', fill='y', padx=5, pady=5)
        ttk.Label(left, text="Список папок:").pack(anchor='nw')
        self.lst_folders = tk.Listbox(left, height=20)
        self.lst_folders.pack(fill='y')
        for d in self._list_folders():
            self.lst_folders.insert(tk.END, d)
        self.lst_folders.bind('<<ListboxSelect>>', self._on_folder_select)
        ttk.Button(left, text="Создать новую папку", command=self._create_folder).pack(fill='x', pady=2)
        ttk.Button(left, text="Удалить выбранную папку", command=self._delete_folder).pack(fill='x', pady=2)

        right = ttk.Frame(frame)
        right.pack(side='right', fill='both', expand=True, padx=5, pady=5)
        self.var_add = tk.BooleanVar()
        ttk.Checkbutton(right, text="Автоматически добавлять новые каналы", variable=self.var_add).pack(anchor='nw')

        for label, attr in (
                ("channel.txt (статические каналы)", 'txt_channel'),
                ("joined_channels.txt (авто-добавленные)", 'txt_joined'),
                ("template.txt (ответ на упоминание)", 'txt_tmpl'),
                ("template_private.txt (ответ в ЛС)", 'txt_priv'),
                ("template_channel.txt (рассылка)", 'txt_chan_tmpl'),
        ):
            ttk.Label(right, text=label).pack(anchor='nw')
            setattr(self, attr, scrolledtext.ScrolledText(right, height=4))
            getattr(self, attr).pack(fill='x', pady=2)

        ttk.Button(right, text="Сохранить настройки папки", command=self._save_folder).pack(pady=10)

    def _create_folder(self):
        name = simpledialog.askstring("Новая папка", "Введите имя папки:")
        if not name:
            return
        path = os.path.join(FOLDERS_DIR, name)
        os.makedirs(path, exist_ok=True)
        for fn in (
                'channel.txt', 'joined_channels.txt',
                'template.txt', 'template_private.txt',
                'template_channel.txt', 'ADD_NEW_CHANNELS.txt'
        ):
            open(os.path.join(path, fn), 'a', encoding='utf-8').close()
        self._refresh_folders_list()

    def _delete_folder(self):
        sel = self.lst_folders.curselection()
        if not sel:
            return
        folder = self.lst_folders.get(sel[0])
        if messagebox.askyesno("Подтверждение", f"Удалить папку «{folder}» вместе с содержимым?"):
            shutil.rmtree(os.path.join(FOLDERS_DIR, folder))
            self._refresh_folders_list()

    def _refresh_folders_list(self):
        self.lst_folders.delete(0, tk.END)
        for d in self._list_folders():
            self.lst_folders.insert(tk.END, d)
        self.cmb_folder['values'] = self._list_folders()

    def _on_folder_select(self, _):
        sel = self.lst_folders.curselection()
        if not sel:
            return
        folder = self.lst_folders.get(sel[0])
        base = os.path.join(FOLDERS_DIR, folder)

        add_file = os.path.join(base, 'ADD_NEW_CHANNELS.txt')
        self.var_add.set(
            os.path.exists(add_file) and
            open(add_file, encoding='utf-8').read().strip().lower() == 'true'
        )
        for fn, widget in (
                ('channel.txt', self.txt_channel),
                ('joined_channels.txt', self.txt_joined),
                ('template.txt', self.txt_tmpl),
                ('template_private.txt', self.txt_priv),
                ('template_channel.txt', self.txt_chan_tmpl),
        ):
            path = os.path.join(base, fn)
            widget.delete('1.0', tk.END)
            if os.path.exists(path):
                widget.insert(tk.END, open(path, encoding='utf-8').read())

    def _save_folder(self):
        sel = self.lst_folders.curselection()
        if not sel:
            return
        folder = self.lst_folders.get(sel[0])
        base = os.path.join(FOLDERS_DIR, folder)
        os.makedirs(base, exist_ok=True)

        with open(os.path.join(base, 'ADD_NEW_CHANNELS.txt'), 'w', encoding='utf-8') as f:
            f.write('True' if self.var_add.get() else 'False')

        for fn, widget in (
                ('channel.txt', self.txt_channel),
                ('joined_channels.txt', self.txt_joined),
                ('template.txt', self.txt_tmpl),
                ('template_private.txt', self.txt_priv),
                ('template_channel.txt', self.txt_chan_tmpl),
        ):
            with open(os.path.join(base, fn), 'w', encoding='utf-8') as f:
                f.write(widget.get('1.0', tk.END).strip())

        messagebox.showinfo("Успех", f"Настройки папки «{folder}» сохранены.")

if __name__ == '__main__':
    app = BotGUI()
    app.mainloop()
